// import React, { useState } from 'react';
import Modal from './Components/Task-3/Model';
import UserData from './Components/Task-2/UserData'
const App = () => {
  // const [isOpen, setIsOpen] = useState(false);

  return (
    <>
    {/* Task-2 */}
      <UserData/>
    {/* Task-3 */}
      {/* <button onClick={() => setIsOpen(true)}>Open Modal</button>
      <Modal isOpen={isOpen} onClose={() => setIsOpen(false)}>
        <h2>Hello World!</h2>
        <p>My name is Harikrishna iam from Hyderabad.</p>
        <button onClick={() => setIsOpen(false)}>Close</button>
      </Modal> */}
    </>
  );
};

export default App;
